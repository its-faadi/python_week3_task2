def display_menu():
    # Displays the menu options to the user
    print("\nList Manager Menu")
    print("1. Add an item to the list")
    print("2. Remove an item from the list by index")
    print("3. Remove an item from the list by value")
    print("4. View all items in the list")
    print("5. Exit")

def add_item(item_list):
    # Adds an item to the list
    item = input("Enter the item to add: ")
    item_list.append(item)
    print(f'Item "{item}" added to the list.')

def remove_item_by_index(item_list):
    # Removes an item from the list by its index    
    try:
        index = int(input("Enter the index of the item to remove: "))
        removed_item = item_list.pop(index)
        print(f'Item "{removed_item}" removed from the list.')
    except ValueError:
        print("Invalid input! Please enter a numeric index.")
    except IndexError:
        print("Index out of range! Please enter a valid index.")

def remove_item_by_value(item_list):
    # Removes an item from the list by its value
    item = input("Enter the item to remove: ")
    try:
        item_list.remove(item)
        print(f'Item "{item}" removed from the list.')
    except ValueError:
        print(f'Item "{item}" not found in the list!')

def view_items(item_list):
    # Displays all items in the list with their indices
    if item_list:
        print("\nItems in the list:")
        for index, item in enumerate(item_list):
            print(f"{index}: {item}")
    else:
        print("The list is empty.")

def main():
    # Main function to run the list manager program
    item_list = []
    while True:
        display_menu()
        choice = input("Enter your choice (1-5): ")
        
        if choice == '1':
            add_item(item_list)
        elif choice == '2':
            remove_item_by_index(item_list)
        elif choice == '3':
            remove_item_by_value(item_list)
        elif choice == '4':
            view_items(item_list)
        elif choice == '5':
            print("Exiting the program. Goodbye!")
            break
        else:
            print("Invalid choice! Please select a valid option.")

if __name__ == "__main__":
    main()
